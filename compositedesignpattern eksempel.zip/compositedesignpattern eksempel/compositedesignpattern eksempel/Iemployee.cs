﻿using System;
using System.Collections.Generic;
using System.Text;

namespace compositedesignpattern_eksempel
{
    public interface IEmployee
    {
        void ShowHappiness();
    }
}
